package compiler.code.translator;

import compiler.intermediate.Temporal;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class RET extends Translator{

	@Override
	protected void translate(QuadrupleIF quadruple) {

		Temporal op1 = (Temporal)quadruple.getResult();
		
		if(op1 != null)
		{
			// Retorno de una funci�n.
			
			// [CI] RET temporal --> [CF] MOVE [.IX], .R0
			//                   --> [CF] INC .R0
			//                   --> [CF] MOVE # [.IX], [.R0]
 			
			// Sentencia RET de una llamada a funci�n. Hay que escribir el valor
			// contenido en el temporal en el valor de retorno del RA del llamador.
			
			setInstruction("MOVE [.IX], .R0");
			setInstruction("INC .R0");
			setInstruction("MOVE "+String.format("#-%s[.IX], .R1", op1.getAddress()));	
		}
		
		setInstruction("RET");		
	}

}
