package compiler.code.translator;

import compiler.intermediate.Temporal;
import compiler.intermediate.Value;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class MOVE extends Translator{

	@Override
	protected void translate(QuadrupleIF quadruple) {

		if(quadruple.getResult() instanceof Temporal)
		{
			// MV	x	y		x := y
			// [CI]MOVE temporal intValue --> [CF]MOVE #, #[.IX]
			
			Value    operando1 = (Value)quadruple.getFirstOperand();
			Temporal operando2 = (Temporal)quadruple.getResult();			
			
			setInstruction("MOVE "+String.format("#%s, #-%s[.IX]", operando1.getValue(), operando2.getAddress()));
		}		
	}

}
