package compiler.code.translator;

import compiler.intermediate.Temporal;
import compiler.intermediate.Variable;
import compiler.semantic.symbol.SymbolVariable;
import es.uned.lsi.compiler.intermediate.OperandIF;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class REG_ACC extends Translator{

	@Override
	protected void translate(QuadrupleIF quadruple) {

        
        OperandIF rdo = quadruple.getResult();
        OperandIF oper1 = quadruple.getFirstOperand();
        OperandIF oper2 = quadruple.getSecondOperand();
        String memoria="";
        
        Variable var2=(Variable) oper2;
        Variable var=(Variable) oper1;
        SymbolVariable SimVar=(SymbolVariable) var.getAmbito().getSymbolTable().getSymbol(var.getName());
        Temporal temp = (Temporal) rdo; 
        temp.setAddress(temp.getAddress()+1);

        memoria="#-" + temp.getAddress() + "[.IX]";
       
        if (SimVar.getScope().getName().equals(var.getScope().getName())) {
        	setInstruction("SUB "+ String.format(".IX , #%s", (SimVar.getDesplazamiento()+var2.getDesplazamientoCampo()))); 
            setInstruction("MOVE "+ String.format("[.A] , %s", memoria));
        } else {

            // Variable en otro ambito 
        	setInstruction("MOVE "+ String.format("%s , .R1", SimVar.getScope().getLevel()));
        	setInstruction("SUB "+ String.format(".R1 , #%s", SimVar.getDesplazamiento()+var2.getDesplazamientoCampo())); 
            setInstruction("MOVE "+ String.format("[A.] , %s", memoria));
        }
	}

}
