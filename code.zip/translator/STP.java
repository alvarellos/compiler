package compiler.code.translator;

import compiler.intermediate.Temporal;
import compiler.intermediate.Value;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class STP extends Translator{

	@Override
	protected void translate(QuadrupleIF quadruple) {
		// STP	x	y		*x := y
		// +----------+----------+
		// |  firsOp  | secondOp |
		// +----------+----------+----------------------------------+
		// | temporal |   null   | Asignaci�n variable/constante    |
		// +----------+----------+----------------------------------+
		// |   null   |   null   | Asignaci�n valor retorno funci�n |
		// +----------+----------+----------------------------------+
		
		Temporal result = (Temporal)quadruple.getResult();	

		setInstruction("MOVE "+String.format("#-%s[.IX], .R0", result.getAddress()));

		
		if(quadruple.getFirstOperand() == null)
		{	
			setInstruction("MOVE "+String.format("#%s[.IX], [.R0]", 1));
		}
		else if(quadruple.getFirstOperand() instanceof Value)
		{
			setInstruction("MOVE #0, [.R0]");	

		}
		else
		{	
			Temporal firstOp = (Temporal)quadruple.getFirstOperand();
			
			if(quadruple.getSecondOperand() == null)
			{
				setInstruction("MOVE "+String.format("#-%s[.IX], [.R0]", firstOp.getAddress()));
			}
			
		}
	}	

	
}
