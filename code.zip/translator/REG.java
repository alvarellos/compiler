package compiler.code.translator;

import compiler.intermediate.Temporal;
import compiler.intermediate.Value;
import compiler.intermediate.Variable;
import compiler.semantic.symbol.SymbolVariable;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;
import es.uned.lsi.compiler.intermediate.OperandIF;

public class REG extends Translator{

	@Override
	protected void translate(QuadrupleIF quadruple) {
		
		// ASIGNACION DE CAMPOS DE RESISTROS
        
        OperandIF rdo= quadruple.getResult();
        OperandIF oper1= quadruple.getFirstOperand();
        OperandIF oper2= quadruple.getSecondOperand();
        
        String operador2="";
        Variable var2=(Variable) oper1;
        Variable var1=(Variable) rdo;
        
        
        SymbolVariable SimVar1=(SymbolVariable) var1.getAmbito().getSymbolTable().getSymbol(var1.getName());

        // Segundo Operador o expresion
        if (oper2 instanceof Value) {
            Value cte = (Value) oper2;
            operador2 = "#" + cte.getValue();
        } else {
            if (oper2 instanceof Variable) {
                Variable var = (Variable) oper2;
                SymbolVariable SimVar = (SymbolVariable) var.getAmbito().getSymbolTable().getSymbol(var.getName());

                if ( SimVar.getScope().getName().equals(SimVar1.getScope().getName()) ){ 
                   operador2 = "#-" + SimVar.getDesplazamiento() + "[.IX]";
                   
                }else {
                	
                 // Variable en otro ambito 
                 setInstruction("MOVE /"+String.format("%s , .R3", SimVar.getScope().getLevel()) );
                 setInstruction("SUB "+String.format(".R3 , #%s", SimVar.getDesplazamiento()));
                 setInstruction("MOVE [.A] , .R4");
                 operador2 = ".R4";
                }
            } else {
                Temporal temp = (Temporal) oper2;
               
               int desp = temp.getAddress();
               
                System.out.println(desp);
                System.out.println(desp);
                operador2 = "#-" + desp + "[.IX]";
                System.out.println("test2");
            }
        }
        
        if (SimVar1.getScope().getName().equals(var1.getScope().getName())) {
        	setInstruction("SUB "+String.format(".IX , #%s", SimVar1.getDesplazamiento()+var2.getDesplazamientoCampo() ));
        } else {
        	
            // Variable en otro ambito 
        	setInstruction("MOVE "+String.format("%s , .R1", SimVar1.getScope().getLevel()));
            setInstruction("SUB "+String.format(".R1 ,#%s", SimVar1.getDesplazamiento()+var2.getDesplazamientoCampo()));

        }
        setInstruction("MOVE "+String.format("%s , [.A]", operador2));
	}
	

}
