package compiler.code.translator;

import compiler.intermediate.Temporal;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class BRF extends Translator {
	
	@Override
	protected void translate(QuadrupleIF quadruple) {

		//[CI]BRF temporal label --> [CF]CMP #, #[.IX]
		//                       --> [CF]BNZ /label
		
		String    operando1 = quadruple.getFirstOperand().toString();
		Temporal  operando2 = (Temporal)quadruple.getResult();
		
		setInstruction("CMP "+String.format("#%s, #-%s[.IX]", 1, operando2.getAddress()));
		setInstruction("BNZ /"+ operando1);		
	}

}
