package compiler.code.translator;

import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class HALT extends Translator{

	@Override
	protected void translate(QuadrupleIF quadruple) {

		setInstruction("HALT");	
		setComment(" --------------------------------------- ");
		setComment("       Fin del c�digo ensamblador        ");
		setComment(" --------------------------------------- ");
	}
	
	

}
