package compiler.code.translator;

import java.util.Iterator;

import compiler.code.ActivaMemoria;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class INIT extends Translator{

	@Override
	protected void translate(QuadrupleIF quadruple) {	

		setComment(" --------------------------------------- ");
		setComment("         Inicio Programa Ens2001         ");
		setComment(" --------------------------------------- ");
		setInstruction("BR /"+ ActivaMemoria.getDireccionSiguinteGlobal());
		
		// Se ensamblan los textos de las E/S
		cargaTextos();
		
		// Se comienza a ensamblar a partir de la direccion global siguiente
		setInstruction("ORG " + ActivaMemoria.getDireccionSiguinteGlobal());
		
		// Se Actualiza el Satck Pointer (SP)
		// Como la pila crece hacia direcciones bajas, los desplazamientos han de ser negativos.
		
		String nameOfMainScope = ActivaMemoria.getAmbitoPrincipal();
		int sizeOfLocalMemory = ActivaMemoria.getTamanioMemoria(nameOfMainScope);		
		int offset = INICIO_PUNTERO_MARCO - (sizeOfLocalMemory + 1);  
		
		// Ajuste de pila
		setInstruction("MOVE "+String.format("#%s, %s", offset, ".SP"));		
		
		// Se almacena en R0 la direcci�n de comienzo del Display
		setInstruction("MOVE "+String.format("#%s, %s", INICIO_DISPLAY, ".R0"));		
		
		// Display[0] = FP del RA del procedimiento principal 
		setInstruction("MOVE "+String.format("#%s, %s", INICIO_PUNTERO_MARCO, "[.R0]"));
		
		// IX debe contener la direcci�n del FP en curso
		setInstruction("MOVE "+String.format("#%s, %s", INICIO_PUNTERO_MARCO, ".IX"));
		
		// Se salta al inicio de la funci�n principal
		setInstruction("BR /L_MAIN");	
	}
	
	private void cargaTextos()
	{
		// Se ensamblan los textos desde la direccion dada por getNextTextAddress()
		setInstruction("ORG " + ActivaMemoria.getDireccionSiguienteTexto());
		
		StringBuilder instructions = new StringBuilder();		
		Iterator<String> it = ActivaMemoria.getTextsHashMap().keySet().iterator();
		
		while(it.hasNext())
		{
			String key = it.next();

			instructions.append( key + ": " + "DATA" + " " + "\"" + ActivaMemoria.getTextsHashMap().get(key) + "\"" + "\n");
		}
		
		instructions.append("\n");
		
		getTranslation().append(instructions.toString());
	}

}