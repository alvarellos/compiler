package compiler.code.translator;

import compiler.intermediate.Temporal;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class GETR1 extends Translator{

	@Override
	protected void translate(QuadrupleIF quadruple) {
		
		setInstruction("MOVE "+String.format(".R1 , #-%s[.IX]", ((Temporal)quadruple.getResult()).getAddress()));
	}
	

}
