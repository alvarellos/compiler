package compiler.code.translator;

import compiler.intermediate.Temporal;
import compiler.intermediate.Value;
import es.uned.lsi.compiler.intermediate.OperandIF;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class WRITE extends Translator{

	@Override
	protected void translate(QuadrupleIF quadruple) {

		OperandIF result = quadruple.getResult();
		
		if(result == null)
		{
			// Entrada sin par�metros.
			// [CI]WRITE null --> 
			
			// Se a�adade New Line + Carriage return
			setInstruction("WRCHAR #10"); // Nueva l�nea
			setInstruction("WRCHAR" + " #13"); // Retorno de carro
		}
		else if(result instanceof Value)
		{
			// [CI]WRITE text --> [CF]WRSTR /
			
			Value v = (Value)result;
			
			if (v.getValue() instanceof String) 
			{
				String label = v.getValue().toString();
				
				setInstruction("WRSTR /" + label);
				
				// Se a�adade New Line + Carriage return
				setInstruction("WRCHAR #10"); // Nueva l�nea
				setInstruction("WRCHAR" + " #13"); // Retorno de carro
			}
		}
		else
		{			
			// [CI]WRITE temporal --> [CF]WRINT #
			
			Temporal operando = (Temporal)quadruple.getResult();	
			
			setInstruction("WRINT " +String.format("#-%s[.IX]", operando.getAddress()));
			
			// Se a�adade New Line + Carriage return
			setInstruction("WRCHAR #10"); // Nueva l�nea
			setInstruction("WRCHAR" + " #13"); // Retorno de carro
			
		}		
	}
	
	
}
