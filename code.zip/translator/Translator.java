package compiler.code.translator;

import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public abstract class Translator {

	
	protected static final int INIICIO_PILA = 65000;
	protected static final int INICIO_DISPLAY = INIICIO_PILA + 2;
	protected static final int INICIO_PUNTERO_MARCO = INIICIO_PILA;
	
	
	private static int nivelActual = 0;
	
	private StringBuilder traduccion;
		

	public Translator() 
	{	
		this.traduccion = new StringBuilder();
	}
	
	protected abstract void translate(QuadrupleIF quadruple);
	
	protected void setInstruction(String instruction)
	{
		this.traduccion.append(instruction + "\n");
	}
	
	protected void setComment(String comment)
	{
		this.traduccion.append("; " + comment + "\n");
	}
	
	public String getQuadrupleTranslation(QuadrupleIF quadruple)
	{	
		this.setComment("CI: " + quadruple.toString());
		this.translate(quadruple);
		
		return this.traduccion.toString();
	}

	public StringBuilder getTranslation()
	{
		return traduccion;
	}

	public void setTranslation(StringBuilder translation) 
	{
		this.traduccion = translation;
	}

	public static int getCurrentLevel() 
	{		
		return nivelActual;
	}

	public static void setCurrentLevel(int currentLevel)
	{			
		Translator.nivelActual = currentLevel;
	}
	
	
}
