package compiler.code.translator;

import compiler.code.Display;
import compiler.intermediate.Temporal;
import compiler.intermediate.Variable;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class MVA extends Translator{

	
	@Override
	protected void translate(QuadrupleIF quadruple) {

		Variable op1 = (Variable)quadruple.getFirstOperand();
		Temporal op2 = (Temporal)quadruple.getResult();
		
		if(op1.isGlobal())
		{
			// Variable global.
			// MVA	x	y		x := &y
			// [CI] MVA temporal variable --> MOVE #, #[.IX]
			setInstruction("MOVE "+String.format("#%s, #-%s[.IX]", op1.getAddress(), op2.getAddress()));

		}
		else if(op1.isParameter())
		{
			// Par�metro. Por tanto la direcci�n asociada est� almacenada en el
			// RA. Como est� por debajo del FP el direccionamiento es positivo.
			
			// [CI] MVA temporal variable --> [CF] MOVE #[.IX], #[.IX]

			setInstruction("MOVE "+String.format("#%s[.IX], #-%s[.IX]", op1.getAddress() + 1, op2.getAddress()));
			
		}
		else if(op1.isNotLocal(Display.inicializado().getNivelActual()))
		{
			// Variable no local / en otro �mbito. Por tanto hay que hacer uso del Display.
						
			// [CI] MVA temporal variable --> [CF] MOVE #, [.Rx]
			//                            --> [CF] SUB [.Rx], #
			//                            --> [CF] MOVE .A, #[.IX]
			
			int offset = INICIO_DISPLAY + op1.getScope().getLevel();			
			
			setInstruction("MOVE "+String.format("#%s, .R0", offset));
			setInstruction("SUB "+String.format("[.R0], #%s", op1.getAddress()));
			setInstruction("MOVE "+String.format(".A, #-%s[.IX]", op2.getAddress()));
			
		}		
		//else if (op1.isLocal())
		else
		{
			// Variable local. Por tanto es necesario almacenar en el temporal

			setInstruction("SUB "+String.format(".IX, #%s", op1.getAddress()));
			setInstruction("MOVE "+String.format(".A, #-%s[.IX]", op2.getAddress()));

			
		}
/*		else // Es un campo de un Registro
		{
			Temporal operando1 = (Temporal)quadruple.getFirstOperand();
			Temporal operando2 = (Temporal)quadruple.getResult();	
			
			
			setInstruction("MOVE "+String.format("#-%s[.IX], .R0", operando1.getAddress()));
			setInstruction("MOVE "+String.format("[.R0], #-%s[.IX]", operando2.getAddress()));
			
		}*/
		
	}
}
