package compiler.code.translator;

import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class BR extends Translator {
	
	@Override
	protected void translate(QuadrupleIF quadruple) {

		// [CI]BR label --> [CF]BR /label
		
		String operando = quadruple.getResult().toString(); 
		setInstruction("BR /"+operando);		
	}
	

}
