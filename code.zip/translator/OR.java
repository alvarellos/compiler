package compiler.code.translator;

import compiler.intermediate.Temporal;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class OR extends Translator {

	@Override
	protected void translate(QuadrupleIF quadruple) {

		// [CI] OR temporal, temporal, temporal --> [CF] OR #[.Ix], #[.Ix]
		//                                       --> [CF] MOVE .A, #[.Ix]		
		
		
		Temporal operando1 = (Temporal)quadruple.getFirstOperand();		
		Temporal operando2 = (Temporal)quadruple.getSecondOperand();
		
		setInstruction("OR "+String.format("#-%s[.IX], #-%s[.IX]", operando1.getAddress(), operando2.getAddress()));
		
		operando1 = (Temporal)quadruple.getResult();
		setInstruction("MOVE "+String.format(".A, #-%s[.IX]", operando1.getAddress()));	
	}
	
	

}
