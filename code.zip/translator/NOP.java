package compiler.code.translator;

import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class NOP extends Translator{

	@Override
	protected void translate(QuadrupleIF quadruple) {

		// [CI]NOP --> [CF]NOP
		setInstruction("NOP");		
	}

}