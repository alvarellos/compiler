package compiler.code.translator;

import compiler.intermediate.Temporal;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class MVP extends Translator{
	
	@Override
	protected void translate(QuadrupleIF quadruple) {
		// MVP	x	y		x := *y
		// [CI] MVP temporal, temporal --> [CF] MOVE # n1 [.IX], .R0
		// [CI] MVP temporal, temporal --> [CF] MOVE .R0, # n2 [.IX]
		Temporal operando1 = (Temporal)quadruple.getFirstOperand();
		Temporal operando2 = (Temporal)quadruple.getResult();	
		
		setInstruction("MOVE "+String.format("#-%s[.IX], .R0", operando1.getAddress()));
		setInstruction("MOVE "+String.format("[.R0], #-%s[.IX]", operando2.getAddress()));
	}

}
