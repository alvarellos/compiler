package compiler.code.translator;

import compiler.code.Display;
import compiler.intermediate.Value;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class INL extends Translator{

	@Override
	protected void translate(QuadrupleIF quadruple) 
	{
		// INL label, value --> Para funciones
		// INL label        --> Para un bloque cualquiera
		
		// [CI]INL label --> [CF]label:		
		setInstruction(quadruple.getResult() + ": ");
				
		if(quadruple.getFirstOperand() != null) 
		{
			// Etiqueta asociada a funci�n. Se recupera el valor del scope
			
			Value value = (Value)quadruple.getFirstOperand();
			Integer iValue = (Integer)value.getValue();

			// se actualiza el estado del Display actual
			Display.inicializado().setNivelActual(iValue);
		}
	}
}
