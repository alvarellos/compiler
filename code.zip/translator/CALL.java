package compiler.code.translator;

import compiler.code.ActivaMemoria;
import compiler.code.Display;
import compiler.intermediate.Procedure;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class CALL extends Translator{
	
	@Override
	protected void translate(QuadrupleIF quadruple) {

		// [CI] CALL procedure --> [CF] MOVE .Rx .Rx 
		// Creaci�n del RA
		
		// 1�: Se reserva espacio para el valor de retorno y se inicializa a 0.

		setInstruction("PUSH #0");		
		
		// 2�: Se almacena el FP del llamador que est� contenido en IX		
		// Almacena puntero de marco del llamador en el campco frame pointer
		
		setInstruction("PUSH .IX");
		
		// 3�: Se actualiza IX con la direcci�n del nuevo RA
		setInstruction("MOVE .SP, .IX");
		setInstruction("INC .IX");

		
		// 4�: Se actualiza el registro SP.
		Procedure proc = (Procedure)quadruple.getResult();	
		int offset = ActivaMemoria.getTamanioMemoria(proc.getName());
		
		setInstruction("SUB "+String.format("%s, #%s",  ".SP", offset));
		setInstruction("MOVE .A, .SP");
		
		// 5�: Display[level] = IX
		// Nivel del llamado
		int nivelLlamado = proc.getScope().getLevel()+1; 
		// Nivel del llamante
		int nivelLlamante = Display.inicializado().getNivelActual(); 
		
		offset = INICIO_DISPLAY + nivelLlamado;
		
		setComment(String.format("Se actualiza el Display[%s] = .IX", nivelLlamado));
		setInstruction("MOVE "+String.format("%s, /%s", ".IX", offset));
		
		// 6�: Se almacena PC en el RA y se salta a la direci�n de la subrutina llamada
		
		// Registro de activaci�n creado. Se ejecuta CALL
		setInstruction("CALL /"+ proc.getCodeLabel());
		
		// Destrucci�n de RA
		
		// Se continua tras el retorno de la funci�n llamada 
		
		// 1�: Display[level] = IX
		// Fin del call y retorno de la llamada. Se destruye RA creado
		
		offset = INICIO_DISPLAY + nivelLlamado;
		
		setComment(String.format("Se actualiza el Display[%s] = [.IX]", nivelLlamado));
		setInstruction("MOVE "+String.format("%s, /%s", "[.IX]", offset));
		
		// Se actualiza el nuevo nivel de anidamiento
		Display.inicializado().setNivelActual(nivelLlamante);	
		
		// 2�: Se actualiza el registro SP
		offset = 1 + proc.get_formalParametersList().size();
		
		setInstruction("MOVE .IX, .SP");
		setInstruction("ADD "+String.format("%s, #%s", ".SP", offset));
		setInstruction("MOVE .A, .SP");
		
		// 3�: Se actualiza IX con la direcci�n del FP del RA del llamador
		setInstruction("MOVE [.IX], .IX");
	}


}
