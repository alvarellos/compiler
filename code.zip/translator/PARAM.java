package compiler.code.translator;

import compiler.intermediate.Temporal;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class PARAM extends Translator{
	
	@Override
	protected void translate(QuadrupleIF quadruple) {

		// [CI] PARAM temporal --> [CF] PUSH
		Temporal op1 = (Temporal)quadruple.getResult();
		setInstruction("PUSH "+String.format("#-%s[.IX]", op1.getAddress()));			
	}

}
