package compiler.code.translator;

import compiler.intermediate.Temporal;
import es.uned.lsi.compiler.intermediate.LabelFactory;
import es.uned.lsi.compiler.intermediate.LabelIF;
import es.uned.lsi.compiler.intermediate.QuadrupleIF;

public class SGT extends Translator {
	
	@Override
	protected void translate(QuadrupleIF quadruple) {

		// [CI] SGT temporal, temporal, temporal --> [CF] CMP #[.Ix], #[.Ix]
		//                                      --> [CF] BP /label2
		//                                      --> [CF] MOVE #1, #[.Ix]
		//                                      --> [CF] BR /label1
		//                                      --> [CF] label2:
		//                                      --> [CF] MOVE #0 #[.Ix]
		//                                      --> [CF] label1:
		
		// Se greneran dos etiquetas nuevas
		LabelFactory lF = new LabelFactory();
		LabelIF l1 = lF.create();
		LabelIF l2 = lF.create();
		
		Temporal operando1 = (Temporal)quadruple.getFirstOperand();
		Temporal operando2 = (Temporal)quadruple.getSecondOperand();
		
		
		setInstruction("CMP "+String.format("#-%s[.IX], #-%s[.IX]", operando1.getAddress(), operando2.getAddress()));
		setInstruction("BP /"+ l2);		
		
		operando1 = (Temporal)quadruple.getResult();
		setInstruction("MOVE "+String.format("#0, #-%s[.IX]", operando1.getAddress()));
		setInstruction("BR /"+ l1);
		
		setInstruction(l2 + ": ");		
		setInstruction("MOVE "+String.format("#1, #-%s[.IX]", operando1.getAddress()));	
		
		setInstruction(l1 + ": ");		
	}

}
