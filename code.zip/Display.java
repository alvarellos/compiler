package compiler.code;

public class Display {
	// Variables
	private static int _nivel_Actual = 0;
	private static Display _inicializado = null;
	
	// Constructor
	protected Display() {
		
	}
	
	// M�todos de la clase
	

	public int getNivelActual() 
	{		
		return _nivel_Actual;
	}
	
	
	public void setNivelActual(int currentLevel)
	{			
		_nivel_Actual = currentLevel;
	}
	
	
	public static Display inicializado()
	{
		if(_inicializado == null)
		{
			_inicializado = new Display();
		}
		
		return _inicializado;
	}


}
