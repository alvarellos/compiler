package compiler.code;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import compiler.CompilerContext;
import compiler.intermediate.Temporal;
import compiler.semantic.symbol.SymbolFunction;
import compiler.semantic.symbol.SymbolParameter;
import compiler.semantic.symbol.SymbolProcedure;
import compiler.semantic.symbol.SymbolVariable;

import es.uned.lsi.compiler.intermediate.TemporalIF;
import es.uned.lsi.compiler.semantic.ScopeIF;
import es.uned.lsi.compiler.semantic.symbol.SymbolIF;

public class ActivaMemoria {

	// Variables
	private static String ambitoPrincipal;
	private static int direccionSiguienteTexto = 0;
	private static int direccionSiguienteGlobal = 2;
	private static LinkedHashMap<String, Integer> tamanioMemoria = new LinkedHashMap<String, Integer>();
	
	// Texto
	
	private static LinkedHashMap<String, String> textsHashMap = new LinkedHashMap<String, String>();
	private static int i = 3;
	private static String keyFalse = "text0";
	private static String keyTrue  = "text1";
	private static String keyErr0  = "text2";
	
	
	// Valores de texto
	static 
	{
		addText(keyFalse, "false");
		addText(keyTrue, "true");
		addText(keyErr0, "Error");
	}
	
	// fin texto
	
	
	// M�todo Activaci�n Memoria
	
	public static void mapeo(){
		
		int direccionLocalSiguienteVariable = 0;
		int direccionLocalSiguienteParametro = 0;
		
		// Todos los ambitos
		List<ScopeIF> todosAmbitos = CompilerContext.getScopeManager().getAllScopes();		
		
		// Se recorren los ambitos y se recuperan los simbolos
		for (ScopeIF scope : todosAmbitos){
			List<SymbolIF> symbols = scope.getSymbolTable().getSymbols();
			
			// Toma el nombre del ambito principal
			if (scope.getLevel() == 0){
				ambitoPrincipal = scope.getName();
			}
			
			// Si el simbolo es una variable puede ser global o no global
			
			for (SymbolIF simboloRecuperado : symbols){
				
				// El simbolo es una variable
				if (simboloRecuperado instanceof SymbolVariable){
					SymbolVariable symbol = (SymbolVariable) simboloRecuperado;
					
					// y es global (nivel 0) se mapea en direccion absoluta
					if (scope.getLevel() == 0){
						symbol.set_direccion(direccionSiguienteGlobal);
						int tamanyo = symbol.getType().getSize();
						// La pr�xima direcci�n sin mapear
						direccionSiguienteGlobal += tamanyo;	
					}
					else{
						// S�mbolo NO global. Variable. Se mapea como una direcci�n local
						int tamanyo = symbol.getType().getSize();
						symbol.set_direccion(direccionLocalSiguienteVariable + tamanyo);
						direccionLocalSiguienteVariable += tamanyo;
					}
				}
				
				// S�mbolo es un par�metro de subprograma
				// Simbolo NO global. Se mapea como una direcci�n local.
				else if ((simboloRecuperado instanceof SymbolFunction)){
					SymbolProcedure simboloProcedimiento = (SymbolFunction) simboloRecuperado;

					// Lista de par�metros
					ArrayList<SymbolParameter> formales = simboloProcedimiento.get_lista_parametros_formales();
					
					int numeroParametros = 0;
					
					if (formales == null) {
						numeroParametros = 0;
					}
					else {

					numeroParametros = formales.size();

					}					
					
					for(int i = numeroParametros - 1; i >= 0; i--){
						SymbolParameter param = formales.get(i);
						// parametros
						int tamanyo = 1;
						param.setAddress(direccionLocalSiguienteParametro + tamanyo);
						direccionLocalSiguienteParametro += tamanyo;						
					}
						

					// Se reinician los contadores de direcci�n locales
					direccionLocalSiguienteParametro = 0;
				}
			}  // Fin de activaci�n elementos en tabla de s�mbolos
			
			// Lista temporales. Variables se mapean como variables locales
			List<TemporalIF> temporales = scope.getTemporalTable().getTemporals();

			for (TemporalIF temporalesLista : temporales) 
			{
				Temporal temporal = (Temporal) temporalesLista;
				
				int tamanyo = temporal.getSize();
				
				temporal.setAddress(direccionLocalSiguienteVariable + tamanyo);
				direccionLocalSiguienteVariable += tamanyo;	
			}
			
			// Se almacena el total de memoria mapeada en el �mbito
			tamanioMemoria.put(scope.getName(), direccionLocalSiguienteVariable);

			// Se reinician los contadores de direcci�n locales
			direccionLocalSiguienteVariable  = 0;
			direccionLocalSiguienteParametro = 0;
			
		} // Fin recorrido �mbito 
		
		
		
		// Reserva de memoria para textos
		direccionSiguienteTexto = direccionSiguienteGlobal;
		asignaMemoriaTexto();
		
	}
	
	// Memoria Texto
	
	private static void asignaMemoriaTexto(){
		LinkedHashMap<String, String> textos = getTextsHashMap();
		
		Iterator<String> iteracion = textos.values().iterator();
		while (iteracion.hasNext()){
			direccionSiguienteGlobal += iteracion.next().length();
		}
	}
	
	
	// Getters and setters
	
	public static LinkedHashMap<String, String> getTextsHashMap()
	{
		return textsHashMap;
	}

	public static String getKeyText() 
	{
		return ("text" + i++);
	}

	public static void addText(String key, String text) 
	{
		text += "\0";
		text = text.replaceAll("\"", "");
		textsHashMap.put(key, text);
	}
	
	public static String getKeyFalse() 
	{
		return keyFalse;
	}
	
	public static String getKeyTrue() 
	{
		return keyTrue;
	}

	public static String getKeyErr0() 
	{
		return keyErr0;
	}

	public static int getDireccionSiguienteTexto() {
		return direccionSiguienteTexto;
	}

	public static void setDireccionSiguienteTexto(int direccionSiguienteTexto) {
		ActivaMemoria.direccionSiguienteTexto = direccionSiguienteTexto;
	}

	public static int getDireccionSiguinteGlobal() {
		return direccionSiguienteGlobal;
	}

	public static void setDireccionSiguinteGlobal(int direccionSiguinteGlobal) {
		ActivaMemoria.direccionSiguienteGlobal = direccionSiguinteGlobal;
	}

	public static String getAmbitoPrincipal() {
		return ambitoPrincipal;
	}

	public static void setAmbitoPrincipal(String ambitoPrincipal) {
		ActivaMemoria.ambitoPrincipal = ambitoPrincipal;
	}

	public static int getTamanioMemoria(String nombre) {
		return tamanioMemoria.get(nombre);
	}

	public static void setTamanioMemoria(LinkedHashMap<String, Integer> tamanioMemoria) {
		ActivaMemoria.tamanioMemoria = tamanioMemoria;
	}
	
}
